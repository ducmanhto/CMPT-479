#pragma once


#include <cstdint>
#include <memory>


namespace frob {


class Frob {
public:
  Frob(uint8_t a, uint32_t b, uint8_t c, uint16_t d, double e, double f, double g, double h)
    : a(a), b(b), c(c), d(d), e(e), f(f), g(g), h(h)
      { }
  
  uint32_t frobnicate(uint32_t first, uint32_t second) const {
    return a*b*first + d*a*c + b*b*c + second;
  }

  uint8_t  getA() const { return a; }
  uint32_t getB() const { return b; }
  uint8_t  getC() const { return c; }
  uint16_t getD() const { return d; }
  double   getE() const { return e; }
  double   getF() const { return f; }
  double   getG() const { return g; }
  double   getH() const { return h; }

private:
  uint8_t a;
  uint32_t b;
  uint8_t c;
  uint16_t d;
  double e;
  double f;
  double g;
  double h;
  
};


}

