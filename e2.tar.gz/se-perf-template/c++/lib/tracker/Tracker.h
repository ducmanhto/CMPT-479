#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
#include <deque>


namespace tracker {


// A simple struct maintaining coordinate locations in an xy-plane.
struct Location {
  uint32_t x;
  uint32_t y;
};


struct ActionPlan {
  std::array<uint8_t,512> secretPlan;
};


// Entities comprise Locations, names, and a plan of action that may contain
// specific, sensitive data.
struct Entity {
  Location location;
  std::string_view name;
  ActionPlan plan;
};


class EntityTracker {
public:
  void
  addEntity(Location location, std::string_view name, const ActionPlan& plan) {
    locations.push_back(location);
    names.push_back(name);
    plans.push_back(plan);
  }

  template<class IsDangerous>
  size_t
  countDangerous(IsDangerous& isDangerous) {
    size_t count = 0;
    const size_t N = locations.size();
    for (size_t i = 0; i < N; ++i) {
      if (isDangerous(locations[i])) {
        ++count;
      }
    }
    
    return count;
  }

  template<class Check>
  void
  checkPlans(Check& check) {
    const size_t N = plans.size();
    for (size_t i = 0; i < N; ++i) {
      check(plans[i]);
    }
  }

private:
  std::vector<Location> locations;
  std::vector<std::string_view> names;
  std::vector<ActionPlan> plans;
};


}

