#pragma once


#include <bit>
#include <cstdint>
#include <vector>


namespace executor {


class Task {
public:
  using TaskKindID = uintptr_t;

  virtual ~Task() = default;

  void doTask() { doTaskImpl(); }
  TaskKindID getTaskKindID() const { return kind; }

  template <typename T>
  static TaskKindID getKindID() {
    return std::bit_cast<TaskKindID>(&kindToken<T>);
  }
  
protected:
  template<typename TaskKind>
  Task(TaskKind*)
    : kind{std::bit_cast<uintptr_t>(&kindToken<TaskKind>)}
      { }

private:
  virtual void doTaskImpl() = 0;

  template <typename TaskKind>
  static inline uint8_t kindToken = 0;
  
  uintptr_t kind;
};


// A simple incrementer task
class Task1 final : public Task {
public:
  Task1(uint32_t& toIncrement)
    : Task{this},
      toIncrement{toIncrement}
      { }

private:
  void
  doTaskImpl() override {
    toIncrement += 1;
  }

  uint32_t& toIncrement;
};


// A simple decrementer task
class Task2 final : public Task {
public:
  Task2(uint32_t& toDecrement)
    : Task{this},
      toDecrement{toDecrement}
      { }

private:
  void
  doTaskImpl() override {
    toDecrement -= 1;
  }

  uint32_t& toDecrement;
};


// A deluxe incrementer task, sold at a premium to the client
class Task3 final : public Task {
public:
  Task3(uint32_t& toIncrement)
    : Task{this},
      toIncrement{toIncrement}
      { }

private:
  void
  doTaskImpl() override {
    toIncrement += 2;
  }

  uint32_t& toIncrement;
};


// The Executor must execute the passed in work whenever execute is called.
class Executor {
public:
  explicit Executor(const std::vector<Task*>& tasks) {
    const auto kind1 = Task::getKindID<Task1>();
    const auto kind2 = Task::getKindID<Task2>();

    for (Task* t : tasks) {
      const auto id = t->getTaskKindID();
      if (id == kind1) {
        task1s.push_back(static_cast<Task1*>(t));
      }
      else if (id == kind2) {
        task2s.push_back(static_cast<Task2*>(t));
      }
      else {
        task3s.push_back(static_cast<Task3*>(t));
      }
    }
  }
  
  void
  execute() {
    for (Task1* t : task1s) {
      t->doTask();
    }

    for (Task2* t : task2s) {
      t->doTask();
    }

    for (Task3* t : task3s) {
      t->doTask();
    }
  }

private:
  std::vector<Task1*> task1s;
  std::vector<Task2*> task2s;
  std::vector<Task3*> task3s;
};


}

