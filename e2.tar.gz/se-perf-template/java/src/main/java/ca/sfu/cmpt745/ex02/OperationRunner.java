package ca.sfu.cmpt745.ex02;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;


public final class OperationRunner {
  private final List<List<Operation>> operationGroups;

  OperationRunner(List<Operation> operations) {
    Map<Class<?>, List<Operation>> groupMap = new HashMap<>();
    for (Operation op : operations) {
      Class<?> opClass = op.getClass();
      groupMap.computeIfAbsent(opClass, k -> new ArrayList<>()).add(op);
    }
    this.operationGroups = new ArrayList<>(groupMap.values());
  }
  
  public final void run() {
    for (List<Operation> group : operationGroups) {
      if (group.isEmpty()) continue;

      Operation first = group.get(0);
      if (first instanceof Add1) {
        processAdd1Group(group);
      } else if (first instanceof Subtract1) {
        processSubtract1Group(group);
      } else if (first instanceof AddConstant) {
        processAddConstantGroup(group);
      } else {
        for (Operation op : group) {
          op.run();
        }
      }
    }
  }

  private void processAdd1Group(List<Operation> group) {
    for (Operation op : group) {
      ((Add1)op).target[0]++;
    }
  }

  private void processSubtract1Group(List<Operation> group) {
    for (Operation op : group) {
      ((Subtract1)op).target[0]--;
    }
  }

  private void processAddConstantGroup(List<Operation> group) {
    for (Operation op : group) {
      AddConstant ac = (AddConstant)op;
      ac.target[0] += ac.constant; 
    }
  }
  
  List<Operation> operations;
}

