package ca.sfu.cmpt745.ex02;


public interface Operation {
  void run();
}
